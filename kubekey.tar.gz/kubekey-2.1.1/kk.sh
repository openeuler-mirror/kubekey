/usr/local/kubekey/kk $*
